package PWR;

import java.util.*;

public class Watek extends Thread {



    private static int[] tablica;
    private static int zakres;
    private static final int dlugoscTablicy = 320000000;
    //private int poczatekSzukania = 0;
    //private static List<Integer> lista = new ArrayList<>();
    private static int count = 0;

    private static int maxTab = Integer.MIN_VALUE;
    private static int minTab = Integer.MAX_VALUE;



    public static void generujTablice() {
        Random rand = new Random();
        tablica = new int[dlugoscTablicy];
        for (int i = 0; i < tablica.length; i++) {
            tablica[i] = rand.nextInt(100000);
        }
        //System.out.println(Arrays.toString(tablica));

    }

//    public static void wyswietlListe(){
//        System.out.println(lista);
//        System.out.println("Max= " + Collections.max(lista) + " min " + Collections.min(lista));
//    }


    public static void generujwatki(int liczbaWatkow) throws InterruptedException {



        zakres = dlugoscTablicy / liczbaWatkow;

        Runnable[] runners = new Runnable[liczbaWatkow];
        Thread[] threads = new Thread[liczbaWatkow];
        for(int i=0; i<liczbaWatkow; i++) {
            runners[i] = new Watek();
        }

        for(int i=0; i<liczbaWatkow; i++) {
            threads[i] = new Thread(runners[i]);
        }

        for(int i=0; i<liczbaWatkow; i++) {
            threads[i].start();
        }
    }




        public synchronized void szukajMinMax (int [] tab, int poczatekSzukania){



           // System.out.println("poczatek szukania: " + poczatekSzukania);

            synchronized (this){
                for (int i = poczatekSzukania; i < poczatekSzukania + zakres; i++) {
                    if (tab[i] < minTab) {
                        minTab = tab[i];
                    }

                    if (tab[i] > maxTab){
                        maxTab = tab[i];
                    }
        }




        }

//            lista.add(maxTab);
//            lista.add(minTab);
    }



    @Override
    public void run() {
        //generujTablice();

        int poczatekSzukania = count++ * zakres;
        szukajMinMax(tablica, poczatekSzukania);


    }

}
