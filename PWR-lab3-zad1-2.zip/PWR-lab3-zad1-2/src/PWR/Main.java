package PWR;

import java.util.Random;
import java.util.Scanner;

public class Main {



    public static void main(String[] args) throws InterruptedException {

            Watek.generujTablice();
        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj liczbę wątków");
        int liczbaWatkow = sc.nextInt();

        long startTime = System.nanoTime();
        Watek.generujwatki(liczbaWatkow);
        long stopTime = System.nanoTime();
        System.out.println("Elapsed time " + (stopTime - startTime));

        //Thread.sleep(400);
       // Watek.wyswietlListe();

        }


}
