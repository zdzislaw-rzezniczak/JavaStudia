package Laboratorium2;

public class Zad3 {
    public static double konwersjaPredkosci(double mileNaH){
        return mileNaH * 1.61;
    }

}
