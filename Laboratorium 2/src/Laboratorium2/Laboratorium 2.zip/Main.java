package Laboratorium2;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println(Zad3.konwersjaPredkosci(1));
        System.out.println(Zad6.kalkulatorMiesiecznegoZobowiazania(150000, 24));
    }
}
