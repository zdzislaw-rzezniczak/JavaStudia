package Lab5;

public interface Uruchomiony extends Runnable{
    boolean isOnOff();
    void wlaczEkspres();
    void wylaczEkspres ();

}
